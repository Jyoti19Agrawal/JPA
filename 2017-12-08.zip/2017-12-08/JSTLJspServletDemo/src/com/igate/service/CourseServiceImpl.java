package com.igate.service;

import java.util.ArrayList;

import com.igate.dao.CourseDaoImpl;
import com.igate.dto.Course;
import com.igate.exception.CourseException;


public class CourseServiceImpl implements ICourseService{
	
	private CourseDaoImpl eDao;
	
	public CourseServiceImpl()
	{
		eDao=new CourseDaoImpl();
	}
	
	public boolean addcourse(Course course) throws CourseException
	{
		return eDao.addcourse(course);
	}
	
	public ArrayList<Course> retrieveAllcourse() throws CourseException
	{
		return eDao.retrieveAllcourse() ;
	}
	
	public Course retrieveCourse(int eid) throws CourseException
	{
		return eDao.retrieveCourse(eid);
	}

	@Override
	public int deleteCourseById(int id) throws CourseException {
		 
		return eDao.deleteCourseById(id);
	}
	
	
}

package com.igate.exception;

public class CourseException extends Exception {

	public CourseException(String message) {
		super(message);
	}

}
